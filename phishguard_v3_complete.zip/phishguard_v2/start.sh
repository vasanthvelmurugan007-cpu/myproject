#!/bin/bash
echo "================================================"
echo "  PHISHGUARD AI v3.0 — Starting"
echo "================================================"
pip install -r requirements.txt -q
echo ""
if [ -z "$GEMINI_API_KEY" ]; then
  echo "  ⚠  Set your API key:"
  echo "  export GEMINI_API_KEY='AIzaSy...'"
  echo "  Or configure it inside the app (⚙ Settings)"
  echo ""
fi
echo "  → Open http://localhost:5000"
echo ""
python app.py
